# Contributing

Please feel free to contribute to the quality of this content by submitting PRs for improvements to code snippets, explanations, etc. If there's any doubt, **open an issue to ask about it before submitting a PR**.

However, if you choose to contribute content (not just typo corrections) to this repo, you agree that you're giving me a non-exclusive license to use that content, as I (and my publisher) deem appropriate. You probably guessed that already, but I just have to make sure the lawyers are happy by explicitly stating it.
